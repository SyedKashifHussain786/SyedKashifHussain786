package edu.disease.ans1;

import java.util.UUID;

/**
 * Represents a disease with a unique ID and name.
 */
public class Disease {
    private UUID diseaseId;
    private String name;

    /**
     * Constructs a Disease instance with the specified disease ID and name.
     *
     * @param diseaseId The unique ID of the disease.
     * @param name      The name of the disease.
     */
    public Disease(UUID diseaseId, String name) {
        this.diseaseId = diseaseId;
        this.name = name;
    }

    /**
     * Gets the unique ID of the disease.
     *
     * @return The disease's unique ID.
     */
    public UUID getDiseaseId() {
        return diseaseId;
    }

    /**
     * Sets the unique ID of the disease.
     *
     * @param diseaseId The unique ID to set for the disease.
     */
    public void setDiseaseId(UUID diseaseId) {
        this.diseaseId = diseaseId;
    }

    /**
     * Gets the name of the disease.
     *
     * @return The name of the disease.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the disease.
     *
     * @param name The name to set for the disease.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Generates a hash code based on the diseaseId.
     *
     * @return The hash code value.
     */
    @Override
    public int hashCode() {
        return diseaseId.hashCode();
    }

    /**
     * Checks if this Disease instance is equal to another object.
     *
     * @param obj The object to compare with.
     * @return True if the objects are equal, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Disease disease = (Disease) obj;
        return diseaseId.equals(disease.diseaseId);
    }

    /**
     * Returns a string representation of the Disease instance.
     *
     * @return The string representation.
     */
    @Override
    public String toString() {
        return "Disease{" +
                "diseaseId=" + diseaseId +
                ", name='" + name + '\'' +
                '}';
    }
}

