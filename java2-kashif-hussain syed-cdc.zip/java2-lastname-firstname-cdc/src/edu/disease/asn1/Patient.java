package edu.disease.ans1;

import java.util.UUID;

public class Patient {
    private Exposure[] exposures1;
    private UUID[] diseaseIds1;
    

    public Patient(Exposure[] exposures, UUID[] diseaseIds) {
        this.exposures1 = exposures;
        this.diseaseIds1 = diseaseIds;
    }

    public Exposure[] getExposures() {
        return exposures1;
    }

    public void setExposures(Exposure[] exposures) {
        this.exposures1 = exposures;
    }

    public UUID[] getDiseaseIds() {
        return diseaseIds1;
    }

    public void setDiseaseIds(UUID[] diseaseIds) {
        this.diseaseIds1 = diseaseIds;
    }

    @Override
    public String toString() {
        StringBuilder exposuresStr = new StringBuilder();
        for (Exposure exposure : exposures1) {
            exposuresStr.append(exposure).append(", ");
        }

        StringBuilder diseaseIdsStr = new StringBuilder();
        for (UUID diseaseId : diseaseIds1) {
            diseaseIdsStr.append(diseaseId).append(", ");
        }

        return "Patient{" +
                "exposures=[" + exposuresStr + "]" +
                ", diseaseIds=[" + diseaseIdsStr + "]" +
                '}';
    }

   
    
    private Exposure[] exposures2;
    private UUID[] diseaseIds2;
	public Object patientId;

    public Patient(int maxExposures, int maxDiseases) {
        this.setExposures2(new Exposure[maxExposures]);
        this.diseaseIds2 = new UUID[maxDiseases];
    }

    // Other methods...

    public void addDiseaseId(UUID diseaseId) {
        for (int i = 0; i < diseaseIds2.length; i++) {
            if (diseaseIds2[i] == null) {
                diseaseIds2[i] = diseaseId;
                return; // Exit the loop once added
            }
        }
        throw new IndexOutOfBoundsException("DiseaseIds array is full.");}
    

    
    public static void main(String[] args) {
        // Create example Exposure instances
        Exposure exposure1 = new Exposure(null, null, null/* ... */);
        Exposure exposure2 = new Exposure(null, null, null/* ... */);

        // Create example UUIDs for diseaseIds
        UUID diseaseId1 = UUID.randomUUID();
        UUID diseaseId2 = UUID.randomUUID();

        // Create a Patient instance
        Patient patient = new Patient(new Exposure[]{exposure1, exposure2}, new UUID[]{diseaseId1, diseaseId2});

        // Print the patient's details
        System.out.println(patient);
        
        
       

       
     
    }

	public Exposure[] getExposures2() {
		return exposures2;
	}

	public void setExposures2(Exposure[] exposures2) {
		this.exposures2 = exposures2;
	}
}


