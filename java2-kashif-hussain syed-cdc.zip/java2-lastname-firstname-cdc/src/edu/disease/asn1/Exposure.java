package edu.disease.ans1;

import java.util.Objects;
import java.util.Scanner;
import java.util.UUID;
import java.time.LocalDateTime;


public class Exposure {

		
    // Properties
    private UUID patientId;
    private LocalDateTime dateTime;
    private String exposureType;

    // Constructor
    public Exposure(UUID patientId, LocalDateTime dateTime, String exposureType) {
        this.patientId = patientId;
        this.dateTime = dateTime;
        this.exposureType = exposureType;
    }

    // Getters and Setters
    public UUID getPatientId() {
        return patientId;
    }

    public void setPatientId(UUID patientId) {
        this.patientId = patientId;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }

    public String getExposureType() {
        return exposureType;
    }

    public void setExposureType(String exposureType) {
        this.exposureType = exposureType;
    }

    // toString method
    @Override
    public String toString() {
        return "Exposure{" +
                "patientId=" + patientId +
                ", dateTime=" + dateTime +
                ", exposureType='" + exposureType + '\'' +
                '}';
    }

    // Example usage
    public static void main(String[] args) {
        UUID patientId = UUID.randomUUID();
        LocalDateTime dateTime = LocalDateTime.now();
        String exposureType = "Air Pollution";

        Exposure exposure = new Exposure(patientId, dateTime, exposureType);
        System.out.println(exposure);
	
        
       
	
    	System.out.println("before exception...");
    	try (Scanner scan = new Scanner(System.in)) {
    		System.out.println("please enter a number...:");
    		int n=scan.nextInt();
    		if(n==0) {
    			throw new ZeroNotGood_VeryBadException("ha ha i did not ask your exam marks...give your friends marks...");
    		}
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	System.out.println("after exception....");	
    }
    }
    class ZeroNotGood_VeryBadException extends Exception{
    /**
    	 * 
    	 */
    	private static final long serialVersionUID = 1L;
    String msg;
    public ZeroNotGood_VeryBadException(String msg) {
    	this.msg=msg;
    }
    public String toString1() {
    	return this.msg;
    }    
        private UUID patientId;
        private LocalDateTime dateTime;
        private String exposureType;

        /**
         * Constructs an Exposure instance.
         *
         * @param patientId     The patient's unique ID.
         * @param dateTime      The exposure event's date and time.
         * @param exposureType  The type of exposure event.
         * @return 
         */
        public void Exposure1(UUID patientId, LocalDateTime dateTime, String exposureType) {
            this.patientId = patientId;
            this.dateTime = dateTime;
            this.exposureType = exposureType;
        }

        /**
         * Gets the patient's unique ID.
         *
         * @return The patient's ID.
         */
        public UUID getPatientId() {
            return patientId;
        }

        /**
         * Gets the exposure event's date and time.
         *
         * @return The date and time of the exposure event.
         */
        public LocalDateTime getDateTime() {
            return dateTime;
        }

        /**
         * Gets the type of exposure event.
         *
         * @return The type of exposure event.
         */
        public String getExposureType() {
            return exposureType;
        }

        /**
         * Generates a hash code based on patientId and dateTime.
         *
         * @return The hash code value.
         */
        @Override
        public int hashCode() {
            return Objects.hash(patientId, dateTime);
        }

        /**
         * Checks if this Exposure instance is equal to another object.
         *
         * @param obj The object to compare with.
         * @return True if the objects are equal, false otherwise.
         */
        @Override
        public boolean equals(Object obj) {
    		return false;
    		
            // Compare patientId and dateTime...
        }

        // toString method...
        @Override
        public String toString() {
            return "Exposure{" +
                    "patientId=" + patientId +
                    ", dateTime=" + dateTime +
                    ", exposureType='" + exposureType + '\'' +
                    '}';
    	
            
            
            
            
            
            
            
            
            
    	
	}
	

}

