package edu.disease.ans1;

public class PatientTest {

}
